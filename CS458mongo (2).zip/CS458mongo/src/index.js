const express = require("express")
const path = require("path")
const app = express()
// const hbs = require("hbs")
const LogInCollection = require("./mongo")
const port = process.env.PORT || 3000
app.use(express.json())

app.use(express.urlencoded({ extended: false }))

const tempelatePath = path.join(__dirname, '../views')
const publicPath = path.join(__dirname, '../public')
console.log(publicPath);

app.set('view engine', 'hbs')
app.set('views', tempelatePath)
app.use(express.static(publicPath))


// hbs.registerPartials(partialPath)


app.get('/signup', (req, res) => {
    res.render('signup')
})
app.get('/', (req, res) => {
    res.render('login')
})



// app.get('/home', (req, res) => {
//     res.render('home')
// })

app.post('/signup', async (req, res) => {
    const username = req.body.name;
    const password = req.body.password;

    // Check if a user with the same username already exists
    const existingUser = await LogInCollection.findOne({ name: username });

    if (existingUser) {
        res.send("User with this username already exists.");
    } else {
        // If not, create a new user and save it to the database
        const newUser = new LogInCollection({ name: username, password: password });
        await newUser.save();
        res.status(201).render("home", {
            naming: username
        });
    }
});



app.post('/login', async (req, res) => {
    try {
        const check = await LogInCollection.findOne({ name: req.body.name });

        if (check) {
            console.log("Retrieved user from DB:", check); // Log the retrieved user
            console.log("Provided password:", req.body.password); // Log the provided password

            if (check.password === req.body.password) {
                res.status(201).render("home", { naming: `${req.body.password}+${req.body.name}` });
            } else {
                res.send("incorrect password");
            }
        } else {
            res.send("User not found");
        }
    } catch (e) {
        console.error("Error during login:", e); // Log the actual error
        res.send("An error occurred during login");
    }
});





app.listen(port, () => {
    console.log('port connected');
})