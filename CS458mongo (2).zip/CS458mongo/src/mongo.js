const mongoose=require("mongoose")

mongoose.connect("mongodb://localhost:27017/TamadaDB")
.then(()=>{
    console.log('mongoose connected');
})
.catch((e)=>{
    console.log('failed', e.message);
})

const logInSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }
})

const LogInCollection = mongoose.model('User', logInSchema, 'Tamada');

module.exports= LogInCollection;